﻿using Microsoft.Data.SqlClient;
using System;
using System.Windows;

namespace BDWpfApp1Empregado
{
    public partial class MainWindow : Window
    {
        SqlConnection? conexao = null;

        public MainWindow()
        {
            InitializeComponent();

            string URL = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=DBEmpregadoGUI;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False;Command Timeout=30";

            try
            {
                conexao = new SqlConnection(URL);
                conexao.Open();
                LabelStatus.Content = "Conexão OK";
            }
            catch (Exception e)
            {
                LabelStatus.Content = "Conexão NOT";
                MessageBox.Show(e.Message);
            }
        }

        private bool VerificarCampos()
        {
            return TextBoxMatricula.Text == "" &&
            return TextBoxCPF.Text != "" &&
            return TextBoxNome.Text != "" &&
            return TextBoxEndereco.Text != "" &&;
        }
        private void LimparCampos()
        {
            return TextBoxMatricula.Text == "" &&
            return TextBoxCPF.Text != "" &&
            return TextBoxNome.Text != "" &&
            return TextBoxEndereco.Text != "" &&;
        }

        public void ButtonSalvar_Click(object sender, RoutedEventArgs e)
        {
            Empregado emp = new()
            {
                CPF = TextBoxCPF.Text,
                Nome = TextBoxNome.Text,
                Endereco = TextBoxEndereco.Text,
            };
            if(conexao != null && VerificarCampos())
            {
                emp.Salvar(conexao);
                LabelStatus.Content = "Salvo OK";
                LimparCampos();
            }
            else
            {
                LabelStatus.Content = "Salvo NOT";
            }
        }
    }
}