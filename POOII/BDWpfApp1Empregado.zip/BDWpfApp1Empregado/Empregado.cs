﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace BDWpfApp1Empregado
{
    internal class Empregado
    {
        public int Matricula { get; set; } = 0;
        public string? CPF { get; set; }
        public string? Nome { get; set; }
        public string? Endereco { get; set; }

        public Empregado() { }
        public Empregado(string cpf, string nome, string endereco)
        {
            CPF = cpf;
            Nome = nome;
            Endereco = endereco;
        }

        public override string ToString()
        {
            return $"Empregado -> Matricula: {Matricula} | CPF: {CPF} |" + $"Nome: {Nome} | Endereço: {Endereco}";
        }

        public void Salvar() { }
        public void Pesquisar() { }
        public void Excluir() { }
        public void Alterar() { }

        public void Salvar(SqlConnection conexao)
        {
            Console.WriteLine("== Salvando Empregado ==");

            if (Matricula == 0)
            {
                var cmd = conexao.CreateCommand();

                cmd.CommandText = "INSERT INTO Empregado (CPF, Nome, Endereco) VALUES (@cpf, @nome, @endereco)";

                cmd.Parameters.Add(new SqlParameter("@cpf", CPF));
                cmd.Parameters.Add(new SqlParameter("@nome", Nome));
                cmd.Parameters.Add(new SqlParameter("@endereco", Endereco));

                cmd.ExecuteNonQuery();
            }
        }
    }

}
